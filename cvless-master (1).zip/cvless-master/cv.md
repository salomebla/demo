---
layout: cv
title: CV
---

# Curriculum Vitæ

{% include contact.html %}

## Section

Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.

* Ut enim ad minim veniam
* Quis nostrud exercitation
* Ullamco laboris nisi
* Ut aliquip ex ea commodo consequat

### Subsection

Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
